# eightdom
Small game about playing against yourself in a terminal.
