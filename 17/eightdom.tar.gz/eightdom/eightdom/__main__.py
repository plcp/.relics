if __name__ == '__main__':
    import eightdom.eightdom
    eightdom.eightdom.bootstrap()
