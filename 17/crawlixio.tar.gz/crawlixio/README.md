
# crawlixio

Poll (« crawl ») [ix.io](http://ix.io) and retrieve pastes.

## Quick setup

Clone, then run the script:

```sh
    git clone https://github.com/plcp/crawlixio.git
    cd crawlixio
    ./crawlixio.sh
```
