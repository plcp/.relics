# learn-keytoy
Toy where few RNN-LSTM learn keystrokes online (based on steckdenis/nnetcpp)
