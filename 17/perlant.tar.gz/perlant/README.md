# perlant
Ants with 20 neurons disposed in one layer evolve to eat perlin noise

# quick setup
Install `matplotlib` and `numpy`, then run:
```sh
    python3 ./start.py
```
