# spock
 Rock-paper-scissors-lizard-spock tournament against a million learning players 

# build
Clone, change directory, make and play:
```
git clone --recursive https://github.com/plcp/spock
cd spock
make
./build/rock-paper-scissors-lizard-spock
```
