
# Cervel

**Unfinished work**

We tried to provides with `cervel.component` a way to build
"units" capable of *forward* and *backward* computations as "calculus graph"
in order to optimize units against basic problems.

The "graph" approach is flawed because it does not capture well the
dependencies of each calculus (or *causality*).

We'll reboot the project with trees and a list-based representation.

