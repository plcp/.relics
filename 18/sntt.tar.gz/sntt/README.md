
# sntt
Rewriting LWE crypto libraries to learn the hard way

# TODO

Use [Sampling exactly from the normal
distribution](https://arxiv.org/pdf/1303.6257.pdf) to sample deviates then
compare results (try [GLITCH](https://eprint.iacr.org/2017/438.pdf) to check
distributions?).
