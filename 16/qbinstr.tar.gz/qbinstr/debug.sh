#!/bin/sh
gdb -q -x ./gdb.source
