#ifndef QBINSTR_ARGS_INFO_H_GUARD_
#define QBINSTR_ARGS_INFO_H_GUARD_
   
extern struct args_info_t args_info;

#endif

