# rudru

rudrudrudduddduddudrudrudduddd

![rudru](src/shrdlu82.jpeg)

## Files provided to the challengers

- `./src/shrdlu82.jpeg`

## Hints

- `./src/hint`

## Regenerate the files

`make # takes few minutes`

## Update the flag

Update `flag` before running `make`.

Note: the `Makefile` checks if the flag can be retrieved with `solve.sh`.
