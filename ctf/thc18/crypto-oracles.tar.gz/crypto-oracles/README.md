
# oracles

Several parts:

- `1/README.md` - very easy (done)
- `2/README.md` - easy (done)
- `3/README.md` - medium (done)

